﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASPNetMVCProject1.Controllers
{
    /*
     * reference: https://weblogs.asp.net/dotnetstories/viewmodels
     public class ProjectViewModel
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Age { get; set; }
        public string Role { get; set; }

        public string ProjectName { get; set; }
    }

    // GET: ProjectEmployees
    public ActionResult Index()
    {
        ProjectsEntities ctx = new ProjectsEntities();

        List<ProjectViewModel> ProjectEmployeeslist = new List<ProjectViewModel>();


        var datalist = (from proj in ctx.Projects
                        join emp in ctx.Employees on proj.ProjectId equals emp.ProjectId
                        select new { proj.ProjectName, emp.Name, emp.Surname, emp.Age, emp.Role }).ToList();


        foreach (var item in datalist)
        {
            ProjectViewModel pvm = new ProjectViewModel();
            pvm.ProjectName = item.ProjectName;
            pvm.Name = item.Name;
            pvm.Surname = item.Surname;
            pvm.Age = item.Age;
            pvm.Role = item.Role;
            ProjectEmployeeslist.Add(pvm);
        }


        return View(ProjectEmployeeslist);
    }
    */
}



