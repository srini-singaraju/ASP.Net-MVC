﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASPNetMVCProject1.Models;

namespace ASPNetMVCProject1.Controllers
{
    public class ProjectEmployeeController : Controller
    {
        ProjectDB db = new ProjectDB();

        // GET: ProjectEmployee
        public ActionResult Index()
        {
            List<ProjectViewModel> projViewModelList = new List<ProjectViewModel>();

            // Join Project table to Employee table on EmpId
            /* using query syntax
            var dataList = from p in db.Project
                           join e in db.Employee on p.EmpId equals e.Id
                           select new { ProjectName = p.Name, EmployeeName = e.Name, EmployeeSalary = e.Salary };
            */

            // using method syntax
            var dataList = db.Project.Join(db.Employee,
                p => p.EmpId, e => e.Id,
                (p, e) => new
                { ProjectName = p.Name, EmployeeName = e.Name, EmployeeSalary = e.Salary }
                );

            foreach (var item in dataList)
            {
                ProjectViewModel pvm = new ProjectViewModel();
                pvm.ProjectName = item.ProjectName;
                pvm.EmployeeName = item.EmployeeName;
                pvm.EmployeeSalary = item.EmployeeSalary;
                projViewModelList.Add(pvm);
            }

            return View(projViewModelList);
        }
    }
}
