﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASPNetMVCProject1.Models;

namespace ASPNetMVCProject1.Controllers
{
    public class EmployeeController : Controller
    {
        EmployeeDB db = new EmployeeDB();

        // GET: Employee
        public ActionResult Index()
        {
            List<Employee> empList = db.Employee.ToList();

            return View(empList);
        }

        public ActionResult Create()
        {            
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            db.Employee.Add(emp);
            db.SaveChanges();
            return RedirectToAction("Index", "Employee");
        }

        public ActionResult Edit(int? Id)
        {
            Employee emp = db.Employee.Where(e => e.Id  == Id).SingleOrDefault();
            return View(emp);
        }

        [HttpPost]
        public ActionResult Edited(Employee emp)
        {            
            if (ModelState.IsValid)
            {
                Employee empEdited = db.Employee.Where(e => e.Id == emp.Id).SingleOrDefault();
                empEdited.Name = emp.Name;
                empEdited.Salary = emp.Salary;
                db.SaveChanges();
                return RedirectToAction("Index", "Employee");
            }
            return View(emp);
        }
        
        public ActionResult Delete(int? Id)
        {
            Employee empDelete = db.Employee.Where(e => e.Id == Id).SingleOrDefault();
            return View(empDelete);
        }
        
        [HttpPost]
        public ActionResult Deleted(Employee emp)
        {
            Employee empDelete = db.Employee.Where(e => e.Id == emp.Id).SingleOrDefault();
            db.Employee.Remove(empDelete);
            db.SaveChanges();
            return RedirectToAction("Index", "Employee");
        }
    }
}