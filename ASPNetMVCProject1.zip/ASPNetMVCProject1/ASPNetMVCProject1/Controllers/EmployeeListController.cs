﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ASPNetMVCProject1.Models;

namespace ASPNetMVCProject1.Controllers
{
    public class EmployeeListController : Controller
    {
        public static List<Employee> listEmployee = new List<Employee>
        {
            new Employee { Id =1, Name = "John", Salary = 3000},
            new Employee { Id =2, Name = "Adam", Salary = 2000},
            new Employee { Id =3, Name = "Sally", Salary = 4000},
        };

        // GET: Employee
        public ActionResult Index()
        {
            return View(listEmployee);
        }


        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            listEmployee.Add(emp);
            // return View(emp);
            // return Content("Employee Added Successfully");
            return RedirectToAction("Index");
        }

        public ActionResult Create()
        {
            Employee emp = new Employee();
            return View(emp);
        }

        public ActionResult Edit(int Id)
        {
            Employee emp = listEmployee.SingleOrDefault(e => e.Id == Id);
            return View(emp);
        }

        [HttpPost]
        public ActionResult Edited(Employee emp)
        {           
            Employee emp1 = listEmployee.SingleOrDefault(e => e.Id == emp.Id);
            listEmployee.Remove(emp1);
            listEmployee.Add(emp);

            //emp1.Id = emp.Id;
            //emp1.Name = emp.Name;
            //emp1.Salary = emp.Salary;

            //listEmployee.RemoveAt(emp.Id - 1);
            //listEmployee.Add(emp1);

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int Id)
        {
            Employee emp = listEmployee.SingleOrDefault(e => e.Id == Id);
            return View(emp);
        }

        public ActionResult Deleted(Employee emp)
        {
            Employee emp1 = listEmployee.SingleOrDefault(e => e.Id == emp.Id);
            listEmployee.Remove(emp1);
            return RedirectToAction("Index");
        }

    }
}