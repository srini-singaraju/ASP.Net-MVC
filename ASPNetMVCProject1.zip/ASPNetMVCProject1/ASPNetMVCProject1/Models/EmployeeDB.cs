﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace ASPNetMVCProject1.Models
{
    public class EmployeeDB : DbContext
    {
        public EmployeeDB() : base("EmployeeDB") { }  // database name
        public DbSet<Employee> Employee { get; set; }
    }
}
